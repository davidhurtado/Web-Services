<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

Yii::setAlias('rest', dirname(dirname(__DIR__)) . '/rest'); // add api alias
Yii::setAlias('soap', dirname(dirname(__DIR__)) . '/soap'); // add api_soap alias