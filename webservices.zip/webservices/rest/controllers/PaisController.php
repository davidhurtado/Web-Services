<?php
 
namespace app\controllers;
 
use yii\rest\ActiveController;
class PaisController extends ActiveController
{
    public $modelClass = 'rest\models\Pais';
}