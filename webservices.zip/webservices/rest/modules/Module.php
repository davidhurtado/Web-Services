<?php
namespace rest\modules;

class Module extends \yii\base\Module
{
    public $controllerNamespace = 'rest\controllers';

    public function init()
    {
        parent::init();
    }
}
