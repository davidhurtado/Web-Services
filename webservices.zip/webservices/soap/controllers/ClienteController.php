<?php

namespace app\controllers;

use yii\helpers\Json;
Use Yii;

class ClienteController extends \yii\web\Controller {

    public function actionIndex() {
        $request = Yii::$app->request;
        if ($request->isGet && $request->isAjax) {
             \Yii::$app->response->format = \yii\web\Response::FORMAT_JSON;
              $cliente = Yii::$app->siteApi;
           
            return $cliente->getPaises(isset($_REQUEST['id']) ? $_REQUEST['id'] : null);
        } else {
            \Yii::$app->response->format = \yii\web\Response::FORMAT_XML;
            $cliente = Yii::$app->siteApi;
            return Json::decode($cliente->getPaises(isset($_GET['id']) ? $_GET['id'] : null));
        }
    }

}
