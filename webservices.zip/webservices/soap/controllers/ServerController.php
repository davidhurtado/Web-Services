<?php

namespace app\controllers;

use soap\models\Pais;
use yii\helpers\Json;

class ServerController extends \yii\web\Controller {

    public function actions() {
        return [
            'paises' => [
                'class' => 'mongosoft\soapserver\Action',
                'serviceOptions' => [
                    'disableWsdlMode' => false,
                ]
            ]
        ];
    }

    /**
     * @param String $name 
     * @return string 
     * @soap 
     */
    public function getPaises($name=null) {
        
        if ($name==null){
            $model = Pais::find()->asArray()->all();
        }else{
            $model = Pais::findOne(['code'=>$name]);
        }
        return Json::encode($model);
    }
}
